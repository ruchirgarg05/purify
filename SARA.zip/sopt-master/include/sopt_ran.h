
#ifndef SOPT_RAN
#define SOPT_RAN

double sopt_ran_gasdev2(int idum);
double sopt_ran_ran2(int idum);
int sopt_ran_knuthshuffle(int *perm, int nperm, int N, int seed);


#endif
